# 文档获取方式

## 免费版

star作者的两个项目，Guns（https://gitee.com/stylefeng/guns）和Roese（https://gitee.com/stylefeng/roses）

加入qq群：254550081（1群） 684163663（2群） 207434260（3群）找群主领取

## 收费版

扫码并支付80元，备注您的邮箱，即可发送到您的邮箱里文档的链接！

![此处输入图片的描述][1]
![此处输入图片的描述][2]

## 文档目录

![输入图片说明](https://images.gitee.com/uploads/images/2018/1017/122726_bf87f30d_551203.png "FireShot Capture 5 - Guns 技术文档 v5.1 - 作业部落 Cmd Mar_ - https___www.zybuluo.com_stylefeng_note_1028072.png")

  [1]: https://gitee.com/uploads/images/2018/0128/181022_1da2a72a_551203.jpeg
  [2]: https://gitee.com/uploads/images/2018/0128/181547_c8ba0119_551203.png